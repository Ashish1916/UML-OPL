let test_multi_step_aexp _ =
  assert_equal (Num 5) (multi_step_aexp (Add (Num 2, Num 3)));
  assert_equal (Num 6) (multi_step_aexp (Mul (Num 2, Num 3)));
  assert_equal (Num 14) (multi_step_aexp (Add (Mul (Num 2, Num 3), Add (Num 5, Num 3))))

let test_multi_step_bexp _ =
  assert_equal (Bool true) (multi_step_bexp (Eq (Num 5, Add (Num 2, Num 3))));
  assert_equal (Bool false) (multi_step_bexp (Leq (Num 5, Num 3)));
  assert_equal (Bool true) (multi_step_bexp (And (Eq (Num 2, Num 2), Leq (Num 1, Num 3))))

let test_equivalence_aexp _ =
  let test_expr = Add (Mul (Num 2, Num 3), Add (Num 5, Num 3)) in
  assert_equal (lstep_aexp test_expr) 
               (match multi_step_aexp test_expr with
                | Num n -> n
                | _ -> failwith "Expected Num")

let test_equivalence_bexp _ =
  let test_expr = And (Eq (Num 2, Num 2), Leq (Num 1, Num 3)) in
  assert_equal (lstep_bexp test_expr)
               (match multi_step_bexp test_expr with
                | Bool b -> b
                | _ -> failwith "Expected Bool")

let suite =
  "HW4 Tests" >::: [
    "test_multi_step_aexp" >:: test_multi_step_aexp;
    "test_multi_step_bexp" >:: test_multi_step_bexp;
    "test_equivalence_aexp" >:: test_equivalence_aexp;
    "test_equivalence_bexp" >:: test_equivalence_bexp;
  ]

let _ = run_test_tt_main suite