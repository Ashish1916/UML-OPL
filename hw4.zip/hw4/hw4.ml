(* Arithmetic expressions *)
type aexp = 
  | Num of int
  | Add of aexp * aexp
  | Mul of aexp * aexp

(* Boolean expressions *)
type bexp =
  | Bool of bool
  | Eq of aexp * aexp
  | Leq of aexp * aexp
  | Not of bexp
  | And of bexp * bexp

exception NoRuleApplies

(* Small-step semantics for arithmetic expressions *)
let rec sstep_aexp a = match a with
  | Num n -> raise NoRuleApplies
  | Add (Num n1, Num n2) -> Num (n1 + n2)
  | Add (a1, a2) -> 
      (try Add (sstep_aexp a1, a2)
       with NoRuleApplies -> Add (a1, sstep_aexp a2))
  | Mul (Num n1, Num n2) -> Num (n1 * n2)  
  | Mul (a1, a2) ->
      (try Mul (sstep_aexp a1, a2)
       with NoRuleApplies -> Mul (a1, sstep_aexp a2))

(* Small-step semantics for boolean expressions *)
let rec sstep_bexp b = match b with
  | Bool _ -> raise NoRuleApplies
  | Eq (Num n1, Num n2) -> Bool (n1 = n2)
  | Eq (a1, a2) ->
      (try Eq (sstep_aexp a1, a2)
       with NoRuleApplies -> Eq (a1, sstep_aexp a2))
  | Leq (Num n1, Num n2) -> Bool (n1 <= n2)
  | Leq (a1, a2) ->
      (try Leq (sstep_aexp a1, a2)
       with NoRuleApplies -> Leq (a1, sstep_aexp a2))
  | Not (Bool b) -> Bool (not b)
  | Not b -> Not (sstep_bexp b)
  | And (Bool true, b2) -> b2
  | And (Bool false, _) -> Bool false
  | And (b1, b2) -> And (sstep_bexp b1, b2)

(* Large-step semantics for arithmetic expressions *)
let rec lstep_aexp a = match a with
  | Num n -> n
  | Add (a1, a2) -> lstep_aexp a1 + lstep_aexp a2
  | Mul (a1, a2) -> lstep_aexp a1 * lstep_aexp a2

(* Large-step semantics for boolean expressions *)
let rec lstep_bexp b = match b with
  | Bool b -> b
  | Eq (a1, a2) -> lstep_aexp a1 = lstep_aexp a2
  | Leq (a1, a2) -> lstep_aexp a1 <= lstep_aexp a2
  | Not b -> not (lstep_bexp b)
  | And (b1, b2) -> lstep_bexp b1 && lstep_bexp b2

(* Multi-step semantics for arithmetic expressions *)
let rec multi_step_aexp a =
  try 
    let a' = sstep_aexp a in
    multi_step_aexp a'
  with
    NoRuleApplies -> a

(* Multi-step semantics for boolean expressions *)
let rec multi_step_bexp b =
  try
    let b' = sstep_bexp b in
    multi_step_bexp b'
  with
    NoRuleApplies -> b